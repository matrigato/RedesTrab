# RedesTrab
Implementação das diversas partes que compõem um cliente e servidor IRC, ou Internet Relay Chat.

Alunos:
Matheus Lopes Rigato - 10260462
Vinicius Ricardo Carvalho - 10724413

Para executar o programa utilize o Makefile na pasta src, utilizando as diretivas make all, para compilar, e make run_main, para execultar.